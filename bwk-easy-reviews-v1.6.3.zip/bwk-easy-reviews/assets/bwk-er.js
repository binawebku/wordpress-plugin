(function($){
function toast(msg){
  const t = $('<div class="bwk-er-toast" role="status" aria-live="polite"></div>').text(msg);
  $('body').append(t);
  setTimeout(()=>t.addClass('show'), 10);
  setTimeout(()=>t.removeClass('show'), 2400);
  setTimeout(()=>t.remove(), 3000);
}
function getContainer(btn){ return $(btn).closest('.bwk-er-card'); }
$(document).on('click', '.bwk-er-star', function(){
  const c = getContainer(this);
  const val = Number($(this).data('value'));
  c.find('.bwk-er-star').attr('aria-pressed','false').removeClass('on');
  c.find('.bwk-er-star').each(function(){
    if (Number($(this).data('value')) <= val) $(this).addClass('on');
  });
  $(this).attr('aria-pressed','true');
  c.data('rating', val);
});
$(document).on('click', '.bwk-er-submit', function(){
  const c = getContainer(this);
  const pid = c.data('product');
  const rating = Number(c.data('rating') || 0);
  const title = c.find('.bwk-er-input').val() || '';
  const content = c.find('.bwk-er-textarea').val() || '';
  if(!rating || !content.trim()){
    toast(BWKER.i18n.error);
    return;
  }
  $(this).prop('disabled', true);
  $.post(BWKER.ajax, {
    action: 'bwk_er_submit_review',
    nonce: BWKER.nonce,
    product_id: pid,
    rating: rating,
    title: title,
    content: content
  }).done(function(resp){
    if(resp && resp.success){
      toast(BWKER.i18n.thank);
      c.addClass('bwk-er-done').html('<p>'+BWKER.i18n.thank+'</p>');
    } else {
      toast((resp && resp.data && resp.data.message) || BWKER.i18n.error);
    }
  }).fail(function(){
    toast(BWKER.i18n.error);
  }).always(()=>$('.bwk-er-submit').prop('disabled', false));
});
$(document).on('click', '.bwk-er-close', function(){
  getContainer(this).fadeOut(150, function(){ $(this).remove(); });
});

// Smooth jump to first review form
$(document).on('click', '.bwk-er-jump', function(e){
  e.preventDefault();
  var $target = $('.bwk-er-card[data-product]').first();
  if ($target.length){
    $('html, body').animate({scrollTop: $target.offset().top - 80}, 400);
    $target.addClass('bwk-er-focus');
    setTimeout(()=> $target.removeClass('bwk-er-focus'), 1200);
  } else {
    toast(BWKER.i18n.login);
  }
});
})(jQuery);